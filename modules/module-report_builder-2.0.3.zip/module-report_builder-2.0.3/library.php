<?php

require_once(__DIR__ . "/code/General.class.php");
require_once(__DIR__ . "/code/Module.class.php");
